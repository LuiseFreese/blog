## Version 1.0.0 (17 April 2021)
- Initial template
- Hugo version 0.80.0
- Bootstrap version v4.5.0